# TRAVEGO SQL PROJECT
-- TASK-1
-- 1. Creating the schema and required tables using sql script or using MySQL workbench

-- a. Create a schema named Travego.
-- b. Create the tables mentioned above with the mentioned column names.

-- Creating a schema named Travego. 
create schema Travego;
use Travego;

# b.Create the tables mentioned above with the mentioned column names. 
# c.Insert the data in the newly created tables using sql script or using MySQL UI. 

-- The tables and the data insert in the tables are done by using MySQL UI.

-- It describe the data and data type.
desc passanger;

-- To show all data in table passanger.
select * from passanger;

-- It describe the data and data type.
desc price;

-- To show all data in table price.
select * from price;


-- TRAVEGO SQL PROJECT
-- TASK-2
-- ------------------------------------------------------------------------------------------------------------------------------------
-- 2. Perform read operation on the designed table created in the above task using SQL script. 

-- A.How many females and how many male passengers traveled a minimum distance of 600 KMs?
SELECT 
    COUNT(*) AS num_passanger, Gender
FROM
    passanger
WHERE
    Distance >= '600'
GROUP BY  Gender;

 -- ---------------------------------------------------------------------------------------------------------   
 
-- B.Find the minimum ticket price of a Sleeper Bus. 
SELECT 
    MIN(Price) minimum_ticket_price, Bus_type
FROM
    price
WHERE
    Bus_type = 'Sleeper';
    
 -- ---------------------------------------------------------------------------------------------------------   

-- C.Select passenger names whose names start with character 'S' ?
SELECT 
    passanger_name
FROM
    passanger
WHERE
    passanger_name LIKE 'S%';
    
 -- ---------------------------------------------------------------------------------------------------------   

-- D.Calculate price charged for each passenger displaying Passenger name, Boarding City, Destination City, Bus_Type, Price in the output
SELECT 
    passanger_name,
    Boarding_city,
    Destination_city,
    Bus_type,
    Price
FROM
    passanger p
         JOIN
    price c USING (Bus_type,Distance);
    
 -- ---------------------------------------------------------------------------------------------------------   

-- E. What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in a bus?  
SELECT 
    passanger_name, Price
FROM
    passanger p
        JOIN
    price c USING (Distance)
WHERE
    Distance = '1000'
        AND category = 'Sitting';
        
 -- ---------------------------------------------------------------------------------------------------------   

-- F. What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji?
SELECT
    Bus_type, price
FROM
    price
WHERE
    distance = (SELECT 
					distance
				FROM
					passenger
				WHERE
					boarding_city = 'Bangaluru' 
					AND destination_city = 'Panaji');
        
 -- ---------------------------------------------------------------------------------------------------------   

-- G.List the distances from the "Passenger" table which are unique (non-repeated distances) in descending order. 
SELECT DISTINCT
    Distance
FROM
    passanger
ORDER BY  Distance DESC;

 -- ---------------------------------------------------------------------------------------------------------   

-- H.Display the passenger name and percentage of distance traveled by that passenger from the total distance traveled by all passengers without using user variables 
SELECT 
    passanger_name,
    (Distance / total_distance) * 100 AS percentage_distance_traveled
FROM
    passanger,
    (SELECT 
        SUM(Distance) total_distance
    FROM
        passanger) total_distance;

