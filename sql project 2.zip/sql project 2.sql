use film_rental;
-- 1. What is the total revenue generated from all rentals in the database?
SELECT 
    SUM(amount) AS rental_revenue
FROM
    payment;
    
 -- --------------------------------------------------------------------------------------------------------------------------   
-- 2.How many rentals were made in each month_name ?
SELECT 
    COUNT(*)  AS count_of_rental,
    MONTHNAME(rental_date) AS month_name 
FROM
    rental
GROUP BY month_name
ORDER BY count_of_rental ;

-- --------------------------------------------------------------------------------------------------------------------------

-- 3.What is the rental rate of the film with the longest title in the database?
SELECT 
    rental_rate, title, LENGTH(title)
FROM
    film
WHERE
    LENGTH(title) = (SELECT 
            MAX(LENGTH(title))
        FROM
            film);

-- --------------------------------------------------------------------------------------------------------------------------
-- 4.What is the average rental rate for films that were taken from the last 30 days from the date("2005-05-05 22:04:30")?
SELECT * FROM rental ORDER BY 2 ASC;
SELECT 
    f.title,
    DATEDIFF(r.rental_date, '2005-05-05 22:04:30') AS difference,
    AVG(rental_rate) AS avg_rent
FROM
    film f
        LEFT JOIN
    inventory i USING (film_id)
        LEFT JOIN
    rental r USING (inventory_id)
WHERE
    DATEDIFF(r.rental_date, '2005-05-05 22:04:30') <= 30
GROUP BY 1 , 2
ORDER BY 1 , 2;
    
  -- --------------------------------------------------------------------------------------------------------------------------  
-- 5.What is the most popular category of films in terms of the number of rentals?
SELECT 
    c.name AS category, COUNT(r.rental_id) AS rentals
FROM
    film f
        INNER JOIN
    inventory i USING (film_id)
        INNER JOIN
    rental r USING (inventory_id)
        INNER JOIN
    film_category fc USING (film_id)
        INNER JOIN
    category c USING (category_id)
GROUP BY 1
ORDER BY rentals DESC
LIMIT 1;

-- --------------------------------------------------------------------------------------------------------------------------
-- 6.Find the longest movie duration from the list of films that have not been rented by any customer.
            
WITH base AS ( 
SELECT title, COUNT(r.rental_id) AS rentals 
FROM film f 
LEFT JOIN inventory i USING(film_id)
LEFT JOIN rental r USING(inventory_id)
GROUP BY 1
ORDER BY rentals ASC)
SELECT f.*, f1.LENGTH
FROM base f 
INNER JOIN film f1 USING(title)
HAVING rentals = 0
ORDER BY 3 DESC 
LIMIT 1;

-- --------------------------------------------------------------------------------------------------------------------------		
-- 7.What is the average rental rate for films, broken down by category?
 SELECT 
    c.name, f.title, AVG(rental_rate)
FROM
    film f
        INNER JOIN
    film_category fc USING (film_id)
        INNER JOIN
    category c USING (category_id)
GROUP BY 1 , 2;

-- -------------------------------------------------------------------------------------------------------------------------- 
-- 8.What is the total revenue generated from rentals for each actor in the database? 
SELECT 
    a.actor_id,
    a.first_name,
    a.last_name,
    SUM(f.rental_rate * f.rental_duration) AS Revenue
FROM
    actor a
        INNER JOIN
    film_actor fa USING (actor_id)
        INNER JOIN
    film f USING (film_id)
GROUP BY 1 , 2 , 3
ORDER BY 1;

-- --------------------------------------------------------------------------------------------------------------------------
-- 9.Show all the actresses who worked in a film having a "Wrestler" in the description.
SELECT 
    first_name, last_name, description
FROM
    actor a
        LEFT JOIN
    film f USING (last_update)
HAVING '%wrestler%';

SELECT DISTINCT
    a.first_name, a.last_name
FROM
    actor a
        INNER JOIN
    film_actor fa USING (actor_id)
        INNER JOIN
    film f USING (film_id)
WHERE
    f.description LIKE '%Wrestler%'
ORDER BY 1;

-- --------------------------------------------------------------------------------------------------------------------------
-- 10.Which customers have rented the same film more than once?
SELECT 
    c.first_name,
    c.last_name,
    f.title,
    COUNT(f.title) AS Times_rented
FROM
    customer c
        INNER JOIN
    rental r USING (customer_id)
        INNER JOIN
    inventory i USING (inventory_id)
        INNER JOIN
    film f USING (film_id)
GROUP BY 1 , 2 , 3
HAVING Times_rented > 1
ORDER BY Times_rented DESC;

-- --------------------------------------------------------------------------------------------------------------------------
-- 11.How many films in the comedy category have a rental rate higher than the average rental rate? 
SELECT 
    c.name, COUNT(DISTINCT f.film_id) AS 'Total films'
FROM
    film f
        INNER JOIN
    film_category fc USING (film_id)
        INNER JOIN
    category c USING (category_id)
WHERE
    c.name LIKE '%comedy%'
        AND f.rental_rate > (SELECT 
            AVG(rental_rate)
        FROM
            film)
GROUP BY 1;

-- --------------------------------------------------------------------------------------------------------------------------
-- 12.Which films have been rented the most by customers living in each city? 
WITH m_rented AS (
SELECT c.city, f.title, COUNT(f.title) AS Times_rented,
ROW_NUMBER() OVER(PARTITION BY c.city) AS Most_rented
FROM customer cu
INNER JOIN rental r USING(customer_id)
LEFT JOIN inventory i USING(inventory_id)
LEFT JOIN film f USING(film_id)
LEFT JOIN address ad USING(address_id)
LEFT JOIN city c USING(city_id)
GROUP BY 1, 2)
SELECT DISTINCT
    city, title, Times_rented
FROM
    m_rented
WHERE
    Most_rented = 1
ORDER BY Times_rented DESC;

-- --------------------------------------------------------------------------------------------------------------------------
-- 13.What is the total amount spent by customers whose rental payments exceed $200? 
SELECT 
    p.customer_id,
    c.first_name,
    c.last_name,
    SUM(p.amount) AS total_amt
FROM
    customer c
        INNER JOIN
    payment p USING (customer_id)
GROUP BY p.customer_id
HAVING total_amt > 200;

-- --------------------------------------------------------------------------------------------------------------------------
-- 14.Display the fields which are having foreign key constraints related to the "rental" table. [Hint: using Information_schema] 
SELECT 
    CONSTRAINT_NAME,
    COLUMN_NAME,
    referenced_table_name,
    referenced_column_name
FROM
    information_schema.key_column_usage
WHERE table_schema='film_rental'
AND TABLE_NAME = 'rental' AND CONSTRAINT_NAME LIKE 'fk_%';
-- --------------------------------------------------------------------------------------------------------------------------
-- 15.Create a View for the total revenue generated by each staff member, broken down by store city with the country name. 
CREATE VIEW Revenue_Generated AS
    SELECT 
        c.city, co.country, st.first_name, st.last_name, SUM(amount)
    FROM
        store s
            INNER JOIN
        address ad USING (address_id)
            INNER JOIN
        city c USING (city_id)
            INNER JOIN
        country co USING (country_id)
            INNER JOIN
        staff st USING (store_id)
            INNER JOIN
        payment p USING (staff_id)
    GROUP BY 1 , 2 , 3 , 4;
SELECT 
    *
FROM
    Revenue_Generated;
    
-- --------------------------------------------------------------------------------------------------------------------------    
-- 16.Create a view based on rental information consisting of visiting_day, customer_name, the title of the film,  no_of_rental_days, the amount paid by the customer along with the percentage of customer spending. 
CREATE VIEW Rental_Info AS 
SELECT r.rental_date AS visiting_day, cu.first_name, cu.last_name, f.title,
DATEDIFF(r.return_date, r.rental_date) AS no_of_rental_days,
p.amount, ROUND(p.amount/(SUM(p.amount) OVER(PARTITION BY cu.first_name))*100,2) AS percentage_spent
FROM customer cu 
INNER JOIN rental r USING(customer_id)
INNER JOIN payment p USING(rental_id)
INNER JOIN inventory i USING(inventory_id)
INNER JOIN film f USING(film_id)
HAVING no_of_rental_days IS NOT NULL;
SELECT * FROM Rental_Info;

-- --------------------------------------------------------------------------------------------------------------------------
-- 17.Display the customers who paid 50% of their total rental costs within one day. 
SELECT 
    c.customer_id,
    f.film_id,
    (f.rental_rate * f.rental_duration) AS rental_cost,
    p.amount,
    (p.amount / (f.rental_rate * f.rental_duration)) * 100 AS pct_paid
FROM
    film f
        JOIN
    inventory i USING (film_id)
        JOIN
    rental r USING (inventory_id)
        JOIN
    customer c USING (customer_id)
        JOIN
    payment p USING (rental_id)
WHERE
    (p.amount / (f.rental_rate * f.rental_duration)) > 0.5
        AND payment_date < DATE_ADD(r.rental_date, INTERVAL 1 DAY);

-- -------------------------------------------------------------------------------------------------------------------------- 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 